﻿Public Class Form1








    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btncontinuar.Click
        Dim nombre As String
        nombre = TextBox1.Text

        If nombre <> "" Then


            Dim formulario2 As New Form2(nombre)
        formulario2.Show()
        Else
        MsgBox("Tu nombre no puede estar vacio")


        End If






    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class

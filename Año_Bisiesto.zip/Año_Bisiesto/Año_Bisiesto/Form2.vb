﻿
Public Class Form2
    Function bisiesto(añobisiesto As Integer) As Boolean
        Dim año As Boolean


        If añobisiesto Mod 4 = 0 Or añobisiesto Mod 100 = 0 Or añobisiesto Mod 400 = 0 Then
            '"El año es bisiesto"
            año = True
        Else
            '"El  año no es bisiesto"
            año = False

        End If
        Return año

    End Function
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
    Private nombre As String

    Public Sub New(ByVal nombre As String)
        InitializeComponent()
        Label1.Text = "!BIENVENIDO" & " " & nombre & "!"
    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load



    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim añobisiesto As String
        Dim color As Color

        añobisiesto = textobienvenido.Text


        If (IsNumeric(añobisiesto)) Then
            If (bisiesto(añobisiesto)) Then
                Label4.Text = añobisiesto & " ¡ES BISIESTO!"
                Label4.BackColor = Color.Green
                Label5.Text = " ¡GRACIAS POR USAR MI PROGRAMA! "
                Label6.Text = " MI NOMBRE ES MATIAS."
                Label7.Text = "SOY ALUMNO DE 3ERO.EMT DE LA ESCUELA TECNICA MARIA ESPINOLA ESPINOLA"

            Else
                Label4.Text = añobisiesto & " ¡NO ES BISIESTO!"
                Label4.BackColor = Color.Red
                Label5.Text = " ¡GRACIAS POR USAR MI PROGRAMA!"
                Label6.Text = "MI NOMBRE ES MATIAS."
                Label7.Text = "SOY ALUMNO DE 3ERO.EMT DE LA ESCUELA TECNICA MARIA ESPINOLA ESPINOLA"
            End If
        Else

            MsgBox("¡EL VALOR INGRESADO NO ES UN AÑO!", MsgBoxStyle.Critical)
        End If

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles textobienvenido.TextChanged

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        End

    End Sub
End Class